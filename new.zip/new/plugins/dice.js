/**
 * 骰子插件 - 支持多枚骰子投掷并显示历史记录
 * 
 * 本插件展示了：
 * - 插件内部状态管理（投掷历史）
 * - 使用 HostAPI 的 storage 持久化数据
 * - 交互式 UI（骰子数量、面数设置）
 */

import { PluginSystem } from '../plugin-system.js'

PluginSystem.register({
  name: 'dice',
  version: '1.0.0',
  displayName: '骰子与随机数',
  description: '投掷多枚骰子，支持自定义面数和数量',
  icon: '🎲',

  activate(api) {
    this.api = api
    this.history = api.storage.get('history') || []
    this.diceCount = api.storage.get('diceCount') || 2
    this.sides = api.storage.get('sides') || 6
  },

  deactivate() {
    this.api = null
  },

  render(container, api) {
    let diceCount = this.diceCount
    let sides = this.sides
    let history = this.history
    let result = null

    const roll = () => {
      const rolls = Array.from({ length: diceCount }, () => Math.floor(Math.random() * sides) + 1)
      const total = rolls.reduce((a, b) => a + b, 0)
      result = { rolls, total, time: new Date().toLocaleTimeString() }
      if (history.length > 50) history.shift()
      history.push(result)
      api.storage.set('history', history)
      renderResult()
      renderHistory()
    }

    const renderResult = () => {
      if (!result) return
      resArea.innerHTML = `
        <div style="display:flex;flex-wrap:wrap;gap:12px;justify-content:center;margin:20px 0">
          ${result.rolls.map((r, i) => `
            <div style="width:56px;height:56px;border:2px solid #1677ff;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:700;color:#1677ff;background:#e6f4ff">
              ${r}
            </div>
          `).join('')}
        </div>
        <div style="text-align:center;font-size:18px;color:#333;font-weight:500">
          合计: <span style="color:#1677ff;font-size:24px">${result.total}</span>
        </div>
        <div style="text-align:center;font-size:12px;color:#bbb;margin-top:4px">${result.time}</div>
      `
    }

    const renderHistory = () => {
      if (history.length === 0) {
        histArea.innerHTML = '<div style="color:#bbb;text-align:center;padding:16px">暂无记录</div>'
        return
      }
      histArea.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <span style="font-size:12px;color:#888">最近 ${history.length} 次记录</span>
          <button id="clearHist" style="padding:2px 8px;border:1px solid #ff4d4f;border-radius:4px;background:#fff;color:#ff4d4f;font-size:12px;cursor:pointer">清除</button>
        </div>
        ${history.slice().reverse().map(h => `
          <div style="display:flex;justify-content:space-between;padding:6px 8px;border-bottom:1px solid #f5f5f5;font-size:13px">
            <span>${h.rolls.join(', ')}</span>
            <span style="font-weight:600;color:#1677ff">= ${h.total}</span>
            <span style="color:#bbb;font-size:11px">${h.time}</span>
          </div>
        `).join('')}
      `
      const clearBtn = histArea.querySelector('#clearHist')
      if (clearBtn) {
        clearBtn.addEventListener('click', () => {
          history = []
          this.history = []
          api.storage.remove('history')
          renderHistory()
        })
      }
    }

    container.innerHTML = `
      <h2>🎲 骰子与随机数</h2>
      <div style="display:flex;gap:16px;align-items:center;margin-bottom:20px;flex-wrap:wrap">
        <div>
          <label style="font-size:13px;color:#888;margin-right:6px">骰子数量:</label>
          <input id="diceCount" type="number" min="1" max="10" value="${diceCount}" style="width:60px;padding:6px 8px;border:1px solid #d9d9d9;border-radius:6px;text-align:center;font-size:14px">
        </div>
        <div>
          <label style="font-size:13px;color:#888;margin-right:6px">面数:</label>
          <input id="diceSides" type="number" min="2" max="100" value="${sides}" style="width:60px;padding:6px 8px;border:1px solid #d9d9d9;border-radius:6px;text-align:center;font-size:14px">
        </div>
        <button id="rollBtn" style="padding:8px 32px;background:#1677ff;color:#fff;border:none;border-radius:6px;font-size:14px;font-weight:500;cursor:pointer">投掷</button>
      </div>
      <div id="resultArea" style="min-height:80px"></div>
      <h3 style="margin-top:24px">📋 投掷记录</h3>
      <div id="historyArea"></div>
    `

    const resArea = container.querySelector('#resultArea')
    const histArea = container.querySelector('#historyArea')
    const countInp = container.querySelector('#diceCount')
    const sidesInp = container.querySelector('#diceSides')
    const rollBtn = container.querySelector('#rollBtn')

    countInp.addEventListener('change', () => {
      diceCount = Math.max(1, Math.min(10, parseInt(countInp.value) || 2))
      countInp.value = diceCount
      api.storage.set('diceCount', diceCount)
    })

    sidesInp.addEventListener('change', () => {
      sides = Math.max(2, Math.min(100, parseInt(sidesInp.value) || 6))
      sidesInp.value = sides
      api.storage.set('sides', sides)
    })

    rollBtn.addEventListener('click', roll)

    renderHistory()
  }
})

console.log('插件已加载: 骰子与随机数')
