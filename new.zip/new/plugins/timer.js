/**
 * 计时器插件 - 秒表与倒计时
 * 
 * 本插件展示了：
 * - 使用 setInterval 的实时计时功能
 * - 插件内部多个独立状态管理
 * - 使用 HostAPI 的 notify 发送通知
 */

import { PluginSystem } from '../plugin-system.js'

function fmt(ms) {
  const t = Math.floor(ms / 1000)
  const h = Math.floor(t / 3600)
  const m = Math.floor((t % 3600) / 60)
  const s = t % 60
  const p = (n, d) => String(n).padStart(d, '0')
  return `${p(h,2)}:${p(m,2)}:${p(s,2)}`
}

PluginSystem.register({
  name: 'timer',
  version: '1.0.0',
  displayName: '计时器',
  description: '秒表计时与倒计时功能',
  icon: '⏱️',

  activate() {},

  deactivate() {},

  render(container, api) {
    container.innerHTML = `
      <h2>⏱️ 计时器</h2>
      <div style="display:flex;gap:0;margin-bottom:24px;border-bottom:2px solid #e8e8e8">
        <button id="tabStopwatch" class="tab-btn active" style="flex:1;padding:10px 0;border:none;border-bottom:2px solid #1677ff;background:transparent;color:#1677ff;font-weight:600;font-size:14px;cursor:pointer">秒表</button>
        <button id="tabCountdown" class="tab-btn" style="flex:1;padding:10px 0;border:none;border-bottom:2px solid transparent;background:transparent;color:#666;font-size:14px;cursor:pointer">倒计时</button>
      </div>
      <div id="stopwatchPanel">
        <div style="text-align:center;padding:24px 0">
          <div id="swDisplay" style="font-size:52px;font-family:'Cascadia Code','Consolas',monospace;font-weight:700;color:#1677ff;letter-spacing:2px">00:00:00</div>
          <div style="display:flex;gap:12px;justify-content:center;margin-top:24px">
            <button id="swStartBtn" style="padding:8px 32px;background:#1677ff;color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;font-weight:500">开始</button>
            <button id="swResetBtn" style="padding:8px 24px;background:transparent;border:1px solid #d9d9d9;border-radius:6px;color:#666;font-size:14px;cursor:pointer">重置</button>
          </div>
        </div>
      </div>
      <div id="countdownPanel" style="display:none">
        <div style="text-align:center;padding:24px 0">
          <div id="cdDisplay" style="font-size:52px;font-family:'Cascadia Code','Consolas',monospace;font-weight:700;color:#1677ff;letter-spacing:2px">00:05:00</div>
          <div style="display:flex;gap:12px;justify-content:center;margin:20px 0;flex-wrap:wrap">
            <div><label style="font-size:13px;color:#888;display:block;margin-bottom:4px">分钟</label><input id="cdMinutes" type="number" min="0" max="999" value="5" style="width:80px;padding:6px 8px;border:1px solid #d9d9d9;border-radius:6px;text-align:center;font-size:16px"></div>
            <div><label style="font-size:13px;color:#888;display:block;margin-bottom:4px">秒</label><input id="cdSeconds" type="number" min="0" max="59" value="0" style="width:80px;padding:6px 8px;border:1px solid #d9d9d9;border-radius:6px;text-align:center;font-size:16px"></div>
          </div>
          <div style="display:flex;gap:12px;justify-content:center">
            <button id="cdStartBtn" style="padding:8px 32px;background:#1677ff;color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;font-weight:500">开始</button>
            <button id="cdResetBtn" style="padding:8px 24px;background:transparent;border:1px solid #d9d9d9;border-radius:6px;color:#666;font-size:14px;cursor:pointer">重置</button>
          </div>
        </div>
      </div>
    `

    // Tab switching
    const showTab = (tab) => {
      container.querySelectorAll('.tab-btn').forEach(b => {
        b.style.borderBottomColor = 'transparent'
        b.style.color = '#666'
        b.style.fontWeight = '400'
      })
      container.querySelector('#stopwatchPanel').style.display = tab === 'stopwatch' ? 'block' : 'none'
      container.querySelector('#countdownPanel').style.display = tab === 'countdown' ? 'block' : 'none'
    }

    container.querySelector('#tabStopwatch').addEventListener('click', () => {
      container.querySelector('#tabStopwatch').style.borderBottomColor = '#1677ff'
      container.querySelector('#tabStopwatch').style.color = '#1677ff'
      container.querySelector('#tabStopwatch').style.fontWeight = '600'
      showTab('stopwatch')
    })
    container.querySelector('#tabCountdown').addEventListener('click', () => {
      container.querySelector('#tabCountdown').style.borderBottomColor = '#1677ff'
      container.querySelector('#tabCountdown').style.color = '#1677ff'
      container.querySelector('#tabCountdown').style.fontWeight = '600'
      showTab('countdown')
    })

    // --- Stopwatch ---
    let swRunning = false
    let swElapsed = 0
    let swStartTime = 0
    let swInterval = null

    const swDisp = container.querySelector('#swDisplay')
    const swStartBtn = container.querySelector('#swStartBtn')
    const swResetBtn = container.querySelector('#swResetBtn')

    const swUpdate = () => {
      if (swRunning) {
        swElapsed += Date.now() - swStartTime
        swStartTime = Date.now()
      }
      swDisp.textContent = fmt(swElapsed)
    }

    swStartBtn.addEventListener('click', () => {
      if (!swRunning) {
        swRunning = true
        swStartTime = Date.now()
        swInterval = setInterval(swUpdate, 100)
        swStartBtn.textContent = '暂停'
        swStartBtn.style.background = '#fa8c16'
      } else {
        swRunning = false
        clearInterval(swInterval)
        swElapsed += Date.now() - swStartTime
        swDisp.textContent = fmt(swElapsed)
        swStartBtn.textContent = '继续'
        swStartBtn.style.background = '#1677ff'
      }
    })

    swResetBtn.addEventListener('click', () => {
      swRunning = false
      clearInterval(swInterval)
      swElapsed = 0
      swDisp.textContent = fmt(0)
      swStartBtn.textContent = '开始'
      swStartBtn.style.background = '#1677ff'
    })

    // --- Countdown ---
    let cdRunning = false
    let cdRemaining = 0
    let cdEndTime = 0
    let cdInterval = null

    const cdDisp = container.querySelector('#cdDisplay')
    const cdMinutes = container.querySelector('#cdMinutes')
    const cdSeconds = container.querySelector('#cdSeconds')
    const cdStartBtn = container.querySelector('#cdStartBtn')
    const cdResetBtn = container.querySelector('#cdResetBtn')

    const cdUpdate = () => {
      const r = cdEndTime - Date.now()
      if (r <= 0) {
        clearInterval(cdInterval)
        cdRunning = false
        cdRemaining = 0
        cdDisp.textContent = fmt(0)
        cdDisp.style.color = '#ff4d4f'
        cdStartBtn.textContent = '开始'
        cdStartBtn.style.background = '#1677ff'
        cdMinutes.disabled = false
        cdSeconds.disabled = false
        api.notify('⏰ 倒计时结束', '您设置的倒计时已完成！')
        setTimeout(() => cdDisp.style.color = '#1677ff', 3000)
      } else {
        cdRemaining = r
        cdDisp.textContent = fmt(r)
      }
    }

    cdStartBtn.addEventListener('click', () => {
      if (!cdRunning) {
        const totalMs = (parseInt(cdMinutes.value) || 0) * 60000 + (parseInt(cdSeconds.value) || 0) * 1000
        if (totalMs <= 0) return
        cdRunning = true
        cdEndTime = Date.now() + totalMs
        cdInterval = setInterval(cdUpdate, 100)
        cdStartBtn.textContent = '暂停'
        cdStartBtn.style.background = '#fa8c16'
        cdMinutes.disabled = true
        cdSeconds.disabled = true
      } else {
        cdRunning = false
        clearInterval(cdInterval)
        cdStartBtn.textContent = '继续'
        cdStartBtn.style.background = '#1677ff'
      }
    })

    cdResetBtn.addEventListener('click', () => {
      cdRunning = false
      clearInterval(cdInterval)
      cdRemaining = 0
      cdDisp.textContent = fmt(parseInt(cdMinutes.value) * 60000 + parseInt(cdSeconds.value) * 1000)
      cdStartBtn.textContent = '开始'
      cdStartBtn.style.background = '#1677ff'
      cdMinutes.disabled = false
      cdSeconds.disabled = false
    })
  }
})

console.log('插件已加载: 计时器')
