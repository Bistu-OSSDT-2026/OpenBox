/**
 * 时钟插件 - 显示当前时间，支持时区切换
 * 
 * 本插件展示了插件系统的基本能力：
 * - 使用 HostAPI 获取配置和存储
 * - 渲染实时更新的 UI
 * - 响应交互（时区切换）
 */

import { PluginSystem } from '../plugin-system.js'

const COMMON_TZ = [
  'Asia/Shanghai', 'Asia/Tokyo', 'Asia/Singapore',
  'Europe/London', 'Europe/Paris', 'Europe/Berlin',
  'America/New_York', 'America/Chicago', 'America/Los_Angeles',
  'Australia/Sydney', 'UTC'
]

function getLocalTZ() {
  try { return Intl.DateTimeFormat().resolvedOptions().timeZone }
  catch { return 'Asia/Shanghai' }
}

PluginSystem.register({
  name: 'clock',
  version: '1.0.0',
  displayName: '世界时钟',
  description: '显示当前时间，支持多时区切换',
  icon: '🕐',

  activate(api) {
    this.api = api
    this.tz = api.storage.get('timezone') || getLocalTZ()
    this.showSeconds = api.storage.get('showSeconds') ?? true
  },

  deactivate() {
    clearInterval(this._timer)
    this.api = null
  },

  render(container, api) {
    const tz = this.tz
    const showSeconds = this.showSeconds

    container.innerHTML = `
      <h2>🕐 世界时钟</h2>
      <div style="text-align:center;padding:32px 0">
        <div id="clockDisplay" style="font-size:56px;font-family:'Cascadia Code','Consolas',monospace;font-weight:700;color:#1677ff;letter-spacing:2px">--:--:--</div>
        <div id="clockDate" style="font-size:15px;color:#888;margin-top:8px">--</div>
        <div style="margin-top:20px">
          <label style="font-size:13px;color:#888;margin-right:8px">时区:</label>
          <select id="tzSelect" style="padding:6px 12px;border:1px solid #d9d9d9;border-radius:6px;font-size:14px;min-width:200px">
            ${COMMON_TZ.map(z => `<option value="${z}" ${z === tz ? 'selected' : ''}>${z}</option>`).join('')}
          </select>
        </div>
        <div style="margin-top:12px">
          <label style="font-size:13px;color:#888">
            <input type="checkbox" id="showSecCheck" ${showSeconds ? 'checked' : ''}> 显示秒数
          </label>
        </div>
      </div>
    `

    const disp = container.querySelector('#clockDisplay')
    const dateEl = container.querySelector('#clockDate')
    const tzSel = container.querySelector('#tzSelect')
    const secCb = container.querySelector('#showSecCheck')

    const update = () => {
      const now = new Date()
      const opt = { timeZone: tzSel.value, hour: '2-digit', minute: '2-digit' }
      if (secCb.checked) opt.second = '2-digit'
      const time = new Intl.DateTimeFormat('zh-CN', { ...opt, hour12: false }).format(now)
      const date = new Intl.DateTimeFormat('zh-CN', {
        timeZone: tzSel.value,
        year: 'numeric', month: 'long', day: 'numeric', weekday: 'long'
      }).format(now)
      disp.textContent = time
      dateEl.textContent = date
    }

    update()
    this._timer = setInterval(update, 1000)

    tzSel.addEventListener('change', () => {
      api.storage.set('timezone', tzSel.value)
      this.tz = tzSel.value
    })

    secCb.addEventListener('change', () => {
      api.storage.set('showSeconds', secCb.checked)
      this.showSeconds = secCb.checked
    })
  }
})

console.log('插件已加载: 世界时钟')
