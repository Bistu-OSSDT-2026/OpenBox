/**
 * OpenBox MVP - 插件系统核心
 * 
 * 本模块定义了插件系统的核心架构：
 * 1. PluginAPI - 宿主提供给插件的 API
 * 2. PluginRegistry - 插件注册表，管理插件的生命周期
 * 3. 插件接口规范 - 每个插件必须遵循的契约
 */

/* ========== PluginAPI：宿主能力接口 ========== */

class PluginAPI {
  constructor(pluginId) {
    this.pluginId = pluginId
    this._eventHandlers = {}
  }

  notify(title, body = '') {
    const el = document.createElement('div')
    el.className = 'notification'
    el.innerHTML = `<div class="n-title">${title}</div>
                     ${body ? `<div class="n-body">${body}</div>` : ''}`
    document.body.appendChild(el)
    setTimeout(() => el.remove(), 3000)
  }

  storage = {
    get: (key) => {
      try {
        return JSON.parse(localStorage.getItem(`plugin:${this.pluginId}:${key}`))
      } catch { return null }
    },
    set: (key, value) => {
      localStorage.setItem(`plugin:${this.pluginId}:${key}`, JSON.stringify(value))
    },
    remove: (key) => {
      localStorage.removeItem(`plugin:${this.pluginId}:${key}`)
    }
  }

  emit(event, data) {
    const handlers = this._eventHandlers[event] || []
    handlers.forEach(fn => fn(data))
  }

  on(event, handler) {
    if (!this._eventHandlers[event]) this._eventHandlers[event] = []
    this._eventHandlers[event].push(handler)
    return () => {
      this._eventHandlers[event] = this._eventHandlers[event].filter(h => h !== handler)
    }
  }
}

/* ========== PluginRegistry：插件注册表 ========== */

class PluginRegistry {
  constructor() {
    this._plugins = new Map()
    this._activePlugins = new Set()
    this._listeners = new Set()
  }

  register(pluginModule) {
    const id = pluginModule.name
    if (this._plugins.has(id)) {
      throw new Error(`插件 "${id}" 已注册`)
    }
    this._plugins.set(id, {
      ...pluginModule,
      _api: null,
      _container: null
    })
    this._notify()
    return id
  }

  list() {
    return Array.from(this._plugins.values()).map(p => ({
      name: p.name,
      version: p.version,
      displayName: p.displayName,
      description: p.description,
      icon: p.icon || '🧩',
      enabled: this._activePlugins.has(p.name)
    }))
  }

  get(name) {
    const p = this._plugins.get(name)
    if (!p) return null
    return {
      ...p,
      enabled: this._activePlugins.has(p.name)
    }
  }

  async activate(name) {
    const plugin = this._plugins.get(name)
    if (!plugin) throw new Error(`插件 "${name}" 未找到`)
    if (this._activePlugins.has(name)) return

    const api = new PluginAPI(name)
    plugin._api = api

    try {
      await plugin.activate(api)
      this._activePlugins.add(name)
      this._notify()
    } catch (err) {
      console.error(`插件 "${name}" 激活失败:`, err)
      throw err
    }
  }

  async deactivate(name) {
    const plugin = this._plugins.get(name)
    if (!plugin) throw new Error(`插件 "${name}" 未找到`)
    if (!this._activePlugins.has(name)) return

    try {
      await plugin.deactivate()
    } catch (err) {
      console.error(`插件 "${name}" 停用失败:`, err)
    }

    plugin._api = null
    plugin._container = null
    this._activePlugins.delete(name)
    this._notify()
  }

  render(name, containerEl) {
    const plugin = this._plugins.get(name)
    if (!plugin) throw new Error(`插件 "${name}" 未找到`)
    if (!this._activePlugins.has(name)) throw new Error(`插件 "${name}" 未激活`)

    containerEl.innerHTML = ''
    plugin._container = containerEl
    plugin.render(containerEl, plugin._api)
  }

  onChange(fn) {
    this._listeners.add(fn)
    return () => this._listeners.delete(fn)
  }

  _notify() {
    this._listeners.forEach(fn => fn(this.list()))
  }
}

const PluginSystem = new PluginRegistry()

export { PluginSystem, PluginAPI }
