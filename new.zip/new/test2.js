﻿const http = require('http');
const PORT = 3002;
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('OK');
});
server.listen(PORT, () => {
  const fs = require('fs');
  fs.writeFileSync("C:\\Users\\HANGHA~1\\AppData\\Local\\Temp\\opencode\\test_started.txt", "started");
});
