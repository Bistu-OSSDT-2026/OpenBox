import { join } from 'path'
import { existsSync, mkdirSync } from 'fs'
import { app } from 'electron'
import type { PluginConfig, PluginMeta, PluginLogger, PluginContext, Permission } from './types'
import { PluginRepository, execute as dbExecute, queryAll as dbQueryAll } from './db'
import { PluginSandbox } from './plugin-sandbox'
import { PluginProtocol } from './plugin-protocol'
import { PermissionGuard } from './permission-guard'
import { EventBus } from './event-bus'
import { installFromDirectory, installFromZip, uninstallPlugin as fsUninstall, getAllPlugins, getPlugin } from './plugin-fs'

export class PluginManager {
  private sandboxes: Map<string, PluginSandbox> = new Map()
  private eventBus: EventBus = new EventBus()
  private pluginsDir: string

  constructor(pluginsDir: string) {
    this.pluginsDir = pluginsDir
    if (!existsSync(this.pluginsDir)) mkdirSync(this.pluginsDir, { recursive: true })
    PluginProtocol.register(this.pluginsDir)
  }

  get pluginsPath(): string { return this.pluginsDir }

  async installFromZip(zipPath: string): Promise<PluginMeta> {
    return installFromZip(zipPath, this.pluginsDir)
  }

  installFromDirectory(dirPath: string): PluginMeta {
    return installFromDirectory(dirPath, this.pluginsDir)
  }

  async uninstall(id: string): Promise<void> {
    await this.deactivatePlugin(id)
    fsUninstall(id, this.pluginsDir)
  }

  async activatePlugin(id: string): Promise<void> {
    if (this.sandboxes.has(id)) return

    const plugin = PluginRepository.findById(id)
    if (!plugin) throw new Error(`Plugin ${id} not found`)

    const pluginDir = join(this.pluginsDir, plugin.name)
    if (!existsSync(pluginDir)) throw new Error(`Plugin directory not found: ${pluginDir}`)

    const config = PluginRepository.getConfig(id)
    const permissions = PermissionGuard.parsePermissions(JSON.parse(plugin.permissions || '[]') as string[])

    const logger: PluginLogger = {
      info: (msg, ...args) => this.log(plugin.id, 'info', msg, args),
      warn: (msg, ...args) => this.log(plugin.id, 'warn', msg, args),
      error: (msg, ...args) => this.log(plugin.id, 'error', msg, args),
      debug: (msg, ...args) => this.log(plugin.id, 'debug', msg, args)
    }

    const context: PluginContext = {
      id: plugin.id,
      config,
      logger,
      database: {
        query: (_sql, _params) => {
          new PermissionGuard(permissions).assert('database:read' as Permission)
          return dbQueryAll(_sql, _params)
        },
        execute: (_sql, _params) => {
          new PermissionGuard(permissions).assert('database:write' as Permission)
          dbExecute(_sql, _params)
        }
      },
      api: {
        notify: (title, body) => {
          this.eventBus.emit('api:notify', { pluginId: plugin.id, title, body })
        },
        openDialog: async () => null,
        fetch: async (url, opts) => fetch(url, opts),
        readFile: async (path) => {
          const { readFile } = await import('fs/promises')
          return readFile(path) as unknown as Buffer
        },
        writeFile: async (path, data) => {
          const { writeFile } = await import('fs/promises')
          await writeFile(path, data)
        },
        registerShortcut: (_keys, _handler) => {
          return () => { }
        },
        emitEvent: (event, data) => this.eventBus.emit(event, data),
        onEvent: (event, handler) => this.eventBus.on(event, handler)
      }
    }

    const sandbox = new PluginSandbox({
      pluginId: plugin.id,
      mainEntry: plugin.entry_main,
      permissions,
      pluginDir,
      context
    })

    sandbox.on('message', (msg) => {
      this.eventBus.emit(`plugin:message:${plugin.id}`, msg)
    })

    sandbox.on('error', (err) => {
      logger.error(`Plugin runtime error: ${(err as Error).message}`)
      this.eventBus.emit('plugin:error', { pluginId: plugin.id, error: (err as Error).message })
    })

    await sandbox.start()
    this.sandboxes.set(id, sandbox)
    PluginRepository.updateEnabled(id, true)
    this.eventBus.emit('plugin:status', { pluginId: plugin.id, status: 'active' })
  }

  private async stopPlugin(id: string): Promise<void> {
    const sandbox = this.sandboxes.get(id)
    if (sandbox) {
      this.sandboxes.delete(id)
      await sandbox.stop()
    }
  }

  async deactivatePlugin(id: string): Promise<void> {
    await this.stopPlugin(id)
    PluginRepository.updateEnabled(id, false)
    this.eventBus.emit('plugin:status', { pluginId: id, status: 'inactive' })
  }

  async activateAllEnabled(): Promise<void> {
    const plugins = PluginRepository.getEnabledPlugins()
    for (const plugin of plugins) {
      try {
        await this.activatePlugin(plugin.id)
      } catch (err) {
        console.error(`Failed to activate plugin ${plugin.name}:`, err)
      }
    }
  }

  async deactivateAll(): Promise<void> {
    const activeIds = Array.from(this.sandboxes.keys())
    await Promise.all(activeIds.map(id => this.stopPlugin(id)))
  }

  async sendMessage(id: string, message: unknown): Promise<unknown> {
    let sandbox = this.sandboxes.get(id)
    if (!sandbox) {
      const plugin = PluginRepository.findById(id)
      if (plugin?.enabled) {
        await this.activatePlugin(id)
        sandbox = this.sandboxes.get(id)
      }
    }
    if (!sandbox) throw new Error(`Plugin ${id} is not active`)
    return await sandbox.sendMessage({ type: 'message', payload: message })
  }

  async updateConfig(id: string, config: PluginConfig): Promise<void> {
    PluginRepository.updateConfig(id, config)
    if (this.sandboxes.has(id)) {
      await this.stopPlugin(id)
      await this.activatePlugin(id)
    }
  }

  getInstalledPlugins(): PluginMeta[] {
    return getAllPlugins()
  }

  getPlugin(id: string): PluginMeta | null {
    return getPlugin(id)
  }

  getActivePlugins(): string[] {
    return Array.from(this.sandboxes.keys())
  }

  onEvent(event: string, handler: (data: unknown) => void): () => void {
    return this.eventBus.on(event, handler)
  }

  private log(pluginId: string, level: string, message: string, _args: unknown[]): void {
    dbExecute('INSERT INTO plugin_logs (plugin_id, level, message) VALUES (?, ?, ?)', [pluginId, level, message])
    this.eventBus.emit('plugin:log', { pluginId, level, message })
  }
}
