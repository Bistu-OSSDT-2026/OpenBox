import { fork, ChildProcess } from 'child_process'
import { join } from 'path'
import { pathToFileURL } from 'url'
import { EventEmitter } from 'events'
import { randomUUID } from 'crypto'
import type { PluginMessage, PluginContext, PluginMain, Permission } from './types'

interface PendingRequest {
  resolve: (value: unknown) => void
  reject: (err: Error) => void
  timer: NodeJS.Timeout
}

interface SandboxOptions {
  pluginId: string
  mainEntry: string
  permissions: Permission[]
  pluginDir: string
  context: PluginContext
}

const REQUEST_TIMEOUT = 30000

function resolvePluginMain(loaded: unknown): PluginMain | null {
  let candidate = loaded
  const visited = new Set<unknown>()
  while (candidate !== null && (typeof candidate === 'object' || typeof candidate === 'function') && !visited.has(candidate)) {
    visited.add(candidate)
    const plugin = candidate as Partial<PluginMain> & { default?: unknown }
    if (typeof plugin.activate === 'function') return plugin as PluginMain
    candidate = plugin.default
  }
  return null
}

export class PluginSandbox extends EventEmitter {
  private pluginId: string
  private mainEntry: string
  private permissions: Permission[]
  private pluginDir: string
  private context: PluginContext
  private child: ChildProcess | null = null
  private pluginModule: PluginMain | null = null
  private pendingRequests: Map<string, PendingRequest> = new Map()

  constructor(options: SandboxOptions) {
    super()
    this.pluginId = options.pluginId
    this.mainEntry = options.mainEntry
    this.permissions = options.permissions
    this.pluginDir = options.pluginDir
    this.context = options.context
  }

  async start(): Promise<void> {
    try {
      const entryPath = join(this.pluginDir, this.mainEntry)
      const loaded = await import(pathToFileURL(entryPath).href) as unknown
      this.pluginModule = resolvePluginMain(loaded)
      if (!this.pluginModule) throw new Error('Plugin module does not export activate method')
      await this.pluginModule.activate(this.context)
      this.emit('started')
    } catch (err) {
      this.emit('error', err)
      throw err
    }
  }

  async stop(): Promise<void> {
    if (this.pluginModule) {
      if (typeof this.pluginModule.deactivate === 'function') {
        await this.pluginModule.deactivate()
      }
      this.pluginModule = null
    }
  }

  async sendMessage(message: PluginMessage): Promise<unknown> {
    if (this.pluginModule?.onMessage) {
      return await this.pluginModule.onMessage(message.payload)
    }
    return null
  }

  get isRunning(): boolean {
    return this.pluginModule !== null
  }
}
