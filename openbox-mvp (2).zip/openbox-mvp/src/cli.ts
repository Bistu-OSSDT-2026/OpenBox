#!/usr/bin/env node
import { join } from 'path'
import { existsSync, mkdirSync } from 'fs'
import { homedir } from 'os'
import { initDatabase, PluginRepository, SettingsRepository } from './db'
import { installFromDirectory, installFromZip, uninstallPlugin, getAllPlugins, getPlugin } from './plugin-fs'

const DATA_DIR = process.env.OPENBOX_DATA_DIR || join(homedir(), '.openbox')
const DB_PATH = join(DATA_DIR, 'data', 'openbox.db')
const PLUGINS_DIR = join(DATA_DIR, 'plugins')

async function ensureDirs(): Promise<void> {
  if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true })
  if (!existsSync(join(DATA_DIR, 'data'))) mkdirSync(join(DATA_DIR, 'data'), { recursive: true })
  if (!existsSync(PLUGINS_DIR)) mkdirSync(PLUGINS_DIR, { recursive: true })
}

async function cmdInstall(args: string[]): Promise<void> {
  if (args.length === 0) {
    console.error('Usage: openbox install <path-to-plugin-zip-or-directory>')
    process.exit(1)
  }
  const sourcePath = args[0]
  if (!existsSync(sourcePath)) {
    console.error(`Error: Path not found: ${sourcePath}`)
    process.exit(1)
  }

  try {
    let meta
    if (sourcePath.toLowerCase().endsWith('.zip')) {
      meta = await installFromZip(sourcePath, PLUGINS_DIR)
    } else {
      meta = installFromDirectory(sourcePath, PLUGINS_DIR)
    }
    console.log(`✓ Installed: ${meta.displayName} v${meta.version} (${meta.id})`)
    console.log(`  To enable: openbox enable ${meta.id}`)
  } catch (err) {
    console.error(`✗ Install failed: ${(err as Error).message}`)
    process.exit(1)
  }
}

async function cmdUninstall(args: string[]): Promise<void> {
  if (args.length === 0) {
    console.error('Usage: openbox uninstall <plugin-id>')
    process.exit(1)
  }
  const id = args[0]
  try {
    const plugin = getPlugin(id)
    uninstallPlugin(id, PLUGINS_DIR)
    console.log(`✓ Uninstalled: ${plugin?.displayName || id}`)
  } catch (err) {
    console.error(`✗ Uninstall failed: ${(err as Error).message}`)
    process.exit(1)
  }
}

async function cmdList(): Promise<void> {
  const plugins = getAllPlugins()
  if (plugins.length === 0) {
    console.log('No plugins installed.')
    return
  }

  console.log(`Installed plugins (${plugins.length}):`)
  console.log('')
  for (const p of plugins) {
    const status = p.enabled ? '✓ enabled' : '○ disabled'
    console.log(`  ${p.id.substring(0, 8)}...  ${p.displayName} v${p.version}  [${status}]`)
    console.log(`         ${p.description || '(no description)'}`)
    console.log(`         by ${p.author || 'unknown'}`)
    console.log('')
  }
}

async function cmdEnable(args: string[]): Promise<void> {
  if (args.length === 0) {
    console.error('Usage: openbox enable <plugin-id>')
    process.exit(1)
  }
  const id = args[0]
  const plugin = getPlugin(id)
  if (!plugin) {
    console.error(`✗ Plugin not found: ${id}`)
    process.exit(1)
  }
  PluginRepository.updateEnabled(id, true)
  console.log(`✓ Enabled: ${plugin.displayName}`)
  console.log('  (Run "openbox tray" or restart the tray app to activate)')
}

async function cmdDisable(args: string[]): Promise<void> {
  if (args.length === 0) {
    console.error('Usage: openbox disable <plugin-id>')
    process.exit(1)
  }
  const id = args[0]
  const plugin = getPlugin(id)
  if (!plugin) {
    console.error(`✗ Plugin not found: ${id}`)
    process.exit(1)
  }
  PluginRepository.updateEnabled(id, false)
  console.log(`✓ Disabled: ${plugin.displayName}`)
  console.log('  (Restart the tray app to deactivate)')
}

async function cmdCreatePlugin(args: string[]): Promise<void> {
  const pluginName = args[0]
  if (!pluginName) {
    console.error('Usage: openbox create-plugin <plugin-name>')
    console.error('  Plugin name: lowercase alphanumeric with hyphens/underscores')
    process.exit(1)
  }

  const targetDir = join(process.cwd(), pluginName)
  if (existsSync(targetDir)) {
    console.error(`✗ Directory already exists: ${targetDir}`)
    process.exit(1)
  }

  const templateDir = join(__dirname, '..', 'templates', 'plugin-template')
  if (!existsSync(templateDir)) {
    console.error(`✗ Template directory not found: ${templateDir}`)
    process.exit(1)
  }

  const { readFileSync, writeFileSync, readdirSync, statSync } = await import('fs')

  function copyTemplate(src: string, dest: string): void {
    mkdirSync(dest, { recursive: true })
    for (const entry of readdirSync(src)) {
      const s = join(src, entry)
      const d = join(dest, entry)
      if (statSync(s).isDirectory()) {
        copyTemplate(s, d)
      } else {
        let content = readFileSync(s, 'utf-8')
        content = content
          .replace(/\{\{pluginName\}\}/g, pluginName)
          .replace(/\{\{displayName\}\}/g, pluginName.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()))
        writeFileSync(d, content, 'utf-8')
      }
    }
  }

  copyTemplate(templateDir, targetDir)
  console.log(`✓ Created plugin project: ${targetDir}`)
  console.log(`  cd ${pluginName}`)
  console.log(`  npm install`)
  console.log(`  npm run build`)
}

async function cmdTray(): Promise<void> {
  console.log('Starting OpenBox tray...')
  console.log('  Data directory:', DATA_DIR)
  console.log('  Plugins directory:', PLUGINS_DIR)

  const electronPath = join(__dirname, '..', 'node_modules', '.bin', 'electron')
  const mainPath = join(__dirname, 'main.js')

  if (!existsSync(mainPath)) {
    console.error('✗ Tray app not built. Run "npm run build" first.')
    process.exit(1)
  }

  const { spawn } = await import('child_process')
  const child = spawn(process.execPath, [mainPath], {
    stdio: 'inherit',
    env: { ...process.env, OPENBOX_DATA_DIR: DATA_DIR }
  })

  child.on('exit', (code) => {
    process.exit(code ?? 0)
  })
}

async function cmdInfo(args: string[]): Promise<void> {
  if (args.length === 0) {
    console.log('OpenBox MVP v0.1.0')
    console.log('A minimal extensible desktop toolbox runtime')
    console.log('')
    console.log('Data directory:', DATA_DIR)
    console.log('Plugins directory:', PLUGINS_DIR)
    return
  }

  const id = args[0]
  const plugin = getPlugin(id)
  if (!plugin) {
    console.error(`✗ Plugin not found: ${id}`)
    process.exit(1)
  }

  console.log(`Name:        ${plugin.displayName}`)
  console.log(`ID:          ${plugin.id}`)
  console.log(`Version:     ${plugin.version}`)
  console.log(`Description: ${plugin.description}`)
  console.log(`Author:      ${plugin.author}`)
  console.log(`Status:      ${plugin.enabled ? 'enabled' : 'disabled'}`)
  console.log(`Main entry:  ${plugin.entryMain}`)
  console.log(`Renderer:    ${plugin.entryRenderer || '(none)'}`)
  console.log(`Permissions: ${plugin.permissions.join(', ') || '(none)'}`)
}

async function main(): Promise<void> {
  await ensureDirs()
  await initDatabase(DB_PATH)

  const args = process.argv.slice(2)
  const command = args[0] || 'help'

  switch (command) {
    case 'install':
      await cmdInstall(args.slice(1))
      break
    case 'uninstall':
    case 'remove':
      await cmdUninstall(args.slice(1))
      break
    case 'list':
    case 'ls':
      await cmdList()
      break
    case 'enable':
      await cmdEnable(args.slice(1))
      break
    case 'disable':
      await cmdDisable(args.slice(1))
      break
    case 'create-plugin':
    case 'scaffold':
      await cmdCreatePlugin(args.slice(1))
      break
    case 'tray':
    case 'start':
      await cmdTray()
      break
    case 'info':
      await cmdInfo(args.slice(1))
      break
    case 'help':
    default:
      console.log(`
OpenBox MVP — A minimal extensible desktop toolbox runtime

Usage:
  openbox install <path>         Install plugin from .zip or directory
  openbox uninstall <id>         Uninstall a plugin
  openbox list                   List installed plugins
  openbox enable <id>            Enable a plugin
  openbox disable <id>           Disable a plugin
  openbox info [id]              Show version or plugin details
  openbox create-plugin <name>   Scaffold a new plugin project
  openbox tray                   Start the system tray app
  openbox help                   Show this help message

Environment:
  OPENBOX_DATA_DIR    Data directory (default: ~/.openbox)
`)
      break
  }
}

main().catch(err => {
  console.error('Fatal error:', err)
  process.exit(1)
})
