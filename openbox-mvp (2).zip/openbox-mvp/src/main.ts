import { app, Tray, Menu, dialog, nativeImage, Notification } from 'electron'
import { join } from 'path'
import { existsSync, readFileSync } from 'fs'
import { initDatabase } from './db'
import { PluginManager } from './plugin-manager'
import type { PluginMeta } from './types'

let tray: Tray | null = null
let pluginManager: PluginManager | null = null

function getIconPath(): string {
  const paths = [
    join(__dirname, '..', 'build', 'icon.png'),
    join(__dirname, '..', 'build', 'icon.svg'),
    join(__dirname, '..', '..', 'build', 'icon.png'),
    join(__dirname, '..', '..', 'build', 'icon.svg')
  ]
  for (const p of paths) {
    if (existsSync(p)) return p
  }
  return ''
}

function createTrayMenu(): void {
  if (!pluginManager) return

  const plugins = pluginManager.getInstalledPlugins()
  const activePlugins = pluginManager.getActivePlugins()

  const pluginItems = plugins.length > 0
    ? plugins.map(p => ({
        label: `${p.enabled ? '✓' : '○'} ${p.displayName} (v${p.version})`,
        type: 'checkbox' as const,
        checked: p.enabled,
        click: () => togglePlugin(p.id, !p.enabled)
      }))
    : [{ label: 'No plugins installed', enabled: false }]

  const contextMenu = Menu.buildFromTemplate([
    { label: `OpenBox MVP`, enabled: false },
    { type: 'separator' },
    ...pluginItems,
    { type: 'separator' },
    {
      label: 'Install Plugin...',
      click: async () => {
        const result = await dialog.showOpenDialog({
          properties: ['openFile', 'openDirectory'],
          filters: [
            { name: 'Plugin Package', extensions: ['zip'] },
            { name: 'All Files', extensions: ['*'] }
          ]
        })
        if (result.canceled || !result.filePaths[0]) return

        const selectedPath = result.filePaths[0]
        try {
          let meta: PluginMeta
          if (selectedPath.toLowerCase().endsWith('.zip')) {
            meta = await pluginManager!.installFromZip(selectedPath)
          } else {
            meta = pluginManager!.installFromDirectory(selectedPath)
          }
          await pluginManager!.activatePlugin(meta.id)
          new Notification({ title: 'Plugin Installed', body: `${meta.displayName} v${meta.version}` }).show()
          createTrayMenu()
        } catch (err) {
          dialog.showErrorBox('Install Failed', (err as Error).message)
        }
      }
    },
    { type: 'separator' },
    {
      label: `Active: ${activePlugins.length}/${plugins.length}`,
      enabled: false
    },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ])

  tray?.setContextMenu(contextMenu)

  const activeCount = activePlugins.length
  tray?.setToolTip(`OpenBox MVP — ${activeCount} plugin${activeCount !== 1 ? 's' : ''} active`)
}

async function togglePlugin(id: string, enable: boolean): Promise<void> {
  if (!pluginManager) return
  try {
    if (enable) {
      await pluginManager.activatePlugin(id)
      const plugin = pluginManager.getPlugin(id)
      new Notification({ title: 'Plugin Enabled', body: plugin?.displayName || '' }).show()
    } else {
      await pluginManager.deactivatePlugin(id)
    }
    createTrayMenu()
  } catch (err) {
    dialog.showErrorBox('Error', (err as Error).message)
  }
}

function createTray(): void {
  const iconPath = getIconPath()
  let icon: Electron.NativeImage

  if (iconPath.endsWith('.svg')) {
    const svgContent = readFileSync(iconPath, 'utf-8')
    const size = 16
    const dataUrl = `data:image/svg+xml;base64,${Buffer.from(svgContent).toString('base64')}`
    icon = nativeImage.createFromDataURL(dataUrl)
    icon = icon.resize({ width: size, height: size })
  } else {
    icon = nativeImage.createFromPath(iconPath)
    if (icon.isEmpty()) {
      icon = nativeImage.createEmpty()
    }
  }

  tray = new Tray(icon)
  tray.setToolTip('OpenBox MVP')
  createTrayMenu()
}

app.whenReady().then(async () => {
  try {
    const dbPath = join(app.getPath('userData'), 'data', 'openbox.db')
    await initDatabase(dbPath)
    console.log('Database initialized at:', dbPath)
  } catch (err) {
    console.error('Database init failed:', err)
  }

  try {
    const pluginsDir = join(app.getPath('userData'), 'plugins')
    pluginManager = new PluginManager(pluginsDir)
    console.log('Plugin manager ready at:', pluginsDir)
  } catch (err) {
    console.error('Plugin manager init failed:', err)
  }

  try {
    await pluginManager?.activateAllEnabled()
  } catch (err) {
    console.error('Plugin activation failed:', err)
  }

  createTray()

  pluginManager?.onEvent('plugin:error', (data) => {
    const evt = data as { pluginId: string; error: string }
    new Notification({
      title: 'Plugin Error',
      body: `Plugin ${evt.pluginId}: ${evt.error}`
    }).show()
  })

  pluginManager?.onEvent('api:notify', (data) => {
    const evt = data as { pluginId: string; title: string; body?: string }
    new Notification({ title: evt.title, body: evt.body }).show()
  })

  app.on('activate', () => { })
})

app.on('will-quit', () => {
  void pluginManager?.deactivateAll()
})

app.on('window-all-closed', () => {
  void pluginManager?.deactivateAll()
})
