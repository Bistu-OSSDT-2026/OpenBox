import { join } from 'path'
import { existsSync, mkdirSync, readFileSync, writeFileSync, readdirSync, statSync, rmSync } from 'fs'
import { randomUUID } from 'crypto'
import AdmZip from 'adm-zip'
import type { PluginManifest, PluginMeta, PluginRecord, Permission } from './types'
import { PluginRepository } from './db'

function copyRecursive(src: string, dest: string): void {
  mkdirSync(dest, { recursive: true })
  for (const entry of readdirSync(src)) {
    const s = join(src, entry)
    const d = join(dest, entry)
    if (statSync(s).isDirectory()) {
      copyRecursive(s, d)
    } else {
      writeFileSync(d, readFileSync(s))
    }
  }
}

function resolvePluginRoot(dirPath: string): string {
  if (existsSync(join(dirPath, 'plugin.json'))) return dirPath
  const childDirs = readdirSync(dirPath)
    .map(entry => join(dirPath, entry))
    .filter(entryPath => statSync(entryPath).isDirectory())
  if (childDirs.length === 1 && existsSync(join(childDirs[0], 'plugin.json'))) {
    return childDirs[0]
  }
  return dirPath
}

function validateManifest(manifest: PluginManifest): void {
  if (!manifest.name || !/^[a-z0-9_-]+$/.test(manifest.name)) {
    throw new Error('Plugin name must be lowercase alphanumeric with hyphens/underscores')
  }
  if (!manifest.version) throw new Error('Plugin version is required')
  if (!manifest.displayName) throw new Error('Plugin display name is required')
  if (!manifest.main) throw new Error('Plugin main entry is required')
  if (!Array.isArray(manifest.permissions)) throw new Error('Plugin permissions declaration is invalid')
}

function getManifestDefaults(schema: Record<string, { default?: unknown }>): Record<string, unknown> {
  const config: Record<string, unknown> = {}
  for (const [key, field] of Object.entries(schema)) {
    if (field.default !== undefined) config[key] = field.default
  }
  return config
}

function recordToMeta(record: PluginRecord): PluginMeta {
  return {
    id: record.id,
    name: record.name,
    version: record.version,
    displayName: record.display_name,
    description: record.description,
    author: record.author,
    icon: record.icon || undefined,
    entryMain: record.entry_main,
    entryRenderer: record.entry_renderer || '',
    permissions: JSON.parse(record.permissions || '[]'),
    configSchema: JSON.parse(record.config_schema || '{}'),
    configData: JSON.parse(record.config_data || '{}'),
    enabled: record.enabled === 1,
    installedAt: record.installed_at,
    updatedAt: record.updated_at
  }
}

export function installFromDirectory(sourceDir: string, pluginsDir: string): PluginMeta {
  const pluginRoot = resolvePluginRoot(sourceDir)
  const manifestPath = join(pluginRoot, 'plugin.json')
  if (!existsSync(manifestPath)) throw new Error('plugin.json not found')

  const manifestRaw = readFileSync(manifestPath, 'utf-8')
  const manifest: PluginManifest = JSON.parse(manifestRaw)
  validateManifest(manifest)

  const existing = PluginRepository.findByName(manifest.name)
  if (existing) throw new Error(`Plugin "${manifest.name}" is already installed`)

  const pluginDir = join(pluginsDir, manifest.name)
  if (existsSync(pluginDir)) rmSync(pluginDir, { recursive: true })

  copyRecursive(pluginRoot, pluginDir)

  const id = randomUUID()

  const record: Omit<PluginRecord, 'installed_at' | 'updated_at'> = {
    id,
    name: manifest.name,
    version: manifest.version,
    display_name: manifest.displayName,
    description: manifest.description || '',
    author: manifest.author || '',
    icon: manifest.icon || '',
    entry_main: manifest.main,
    entry_renderer: manifest.renderer || '',
    permissions: JSON.stringify(manifest.permissions),
    config_schema: JSON.stringify(manifest.config || {}),
    config_data: JSON.stringify(getManifestDefaults(manifest.config || {})),
    enabled: 1,
    installed_path: pluginDir
  }

  PluginRepository.create(record)
  return recordToMeta(PluginRepository.findById(id)!)
}

export function installFromZip(zipPath: string, pluginsDir: string): PluginMeta {
  const tempDir = join(pluginsDir, `.tmp-${Date.now()}`)
  mkdirSync(tempDir, { recursive: true })

  try {
    const zip = new AdmZip(zipPath)
    zip.extractAllTo(tempDir, true)
    return installFromDirectory(tempDir, pluginsDir)
  } finally {
    if (existsSync(tempDir)) rmSync(tempDir, { recursive: true, force: true })
  }
}

export function uninstallPlugin(id: string, pluginsDir: string): void {
  const plugin = PluginRepository.findById(id)
  if (!plugin) throw new Error(`Plugin ${id} not found`)

  PluginRepository.delete(id)

  const pluginDir = join(pluginsDir, plugin.name)
  if (existsSync(pluginDir)) rmSync(pluginDir, { recursive: true })
}

export function getAllPlugins(): PluginMeta[] {
  return PluginRepository.findAll().map(recordToMeta)
}

export function getPlugin(id: string): PluginMeta | null {
  const record = PluginRepository.findById(id)
  return record ? recordToMeta(record) : null
}

export { recordToMeta, validateManifest }
