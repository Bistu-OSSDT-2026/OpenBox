import initSqlJs, { Database as SqlJsDatabase, SqlJsStatic } from 'sql.js'
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs'
import { dirname, join } from 'path'
import type { PluginRecord, PluginConfig, ConfigField, Permission } from './types'

let db: SqlJsDatabase | null = null
let SQL: SqlJsStatic | null = null
let currentDbPath: string = ''

function getWasmPath(): string {
  try {
    const sqlJsPath = require.resolve('sql.js')
    const sqlJsDir = dirname(sqlJsPath)
    const wasmPath = join(sqlJsDir, 'sql-wasm.wasm')
    if (existsSync(wasmPath)) return wasmPath
  } catch { }
  try {
    const wasmPath = join(__dirname, '..', 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm')
    if (existsSync(wasmPath)) return wasmPath
  } catch { }
  return ''
}

export async function initDatabase(dbPath: string): Promise<SqlJsDatabase | null> {
  if (db && currentDbPath === dbPath) return db

  try {
    const wasmPath = getWasmPath()
    if (wasmPath && existsSync(wasmPath)) {
      const wasmBinary = readFileSync(wasmPath)
      SQL = await initSqlJs({ wasmBinary })
    } else {
      SQL = await initSqlJs()
    }
  } catch (err) {
    console.error('Failed to initialize sql.js:', err)
    return null
  }

  const dir = dirname(dbPath)
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true })

  try {
    if (existsSync(dbPath)) {
      const buffer = readFileSync(dbPath)
      db = new SQL.Database(buffer)
    } else {
      db = new SQL.Database()
    }
    runMigrations(db)
    persistDatabase(dbPath)
    currentDbPath = dbPath
  } catch (err) {
    console.error('Failed to setup database:', err)
    db = new SQL.Database()
    runMigrations(db)
    currentDbPath = dbPath
  }

  return db
}

function runMigrations(db: SqlJsDatabase): void {
  db.run(`CREATE TABLE IF NOT EXISTS plugins (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    version TEXT NOT NULL,
    display_name TEXT NOT NULL,
    description TEXT DEFAULT '',
    author TEXT DEFAULT '',
    icon TEXT DEFAULT '',
    entry_main TEXT NOT NULL,
    entry_renderer TEXT DEFAULT '',
    permissions TEXT DEFAULT '[]',
    config_schema TEXT DEFAULT '{}',
    config_data TEXT DEFAULT '{}',
    enabled INTEGER DEFAULT 1,
    installed_path TEXT NOT NULL,
    installed_at DATETIME DEFAULT (datetime('now', 'localtime')),
    updated_at DATETIME DEFAULT (datetime('now', 'localtime'))
  )`)
  db.run(`CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  )`)
  db.run(`CREATE TABLE IF NOT EXISTS plugin_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    plugin_id TEXT NOT NULL,
    level TEXT NOT NULL DEFAULT 'info',
    message TEXT NOT NULL,
    timestamp DATETIME DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (plugin_id) REFERENCES plugins(id) ON DELETE CASCADE
  )`)
  db.run('CREATE INDEX IF NOT EXISTS idx_plugin_logs_plugin_id ON plugin_logs(plugin_id)')
  db.run('CREATE INDEX IF NOT EXISTS idx_plugin_logs_timestamp ON plugin_logs(timestamp)')
}

function persistDatabase(dbPath: string): void {
  if (!db) return
  try {
    const data = db.export()
    const buffer = Buffer.from(data)
    writeFileSync(dbPath, buffer)
  } catch (err) {
    console.error('Failed to save database:', err)
  }
}

export function getDatabase(): SqlJsDatabase {
  if (!db) throw new Error('Database not initialized')
  return db
}

export function persist(): void {
  if (!db || !currentDbPath) return
  persistDatabase(currentDbPath)
}

export function closeDatabase(): void {
  if (db) {
    persist()
    db.close()
    db = null
    currentDbPath = ''
  }
}

export function queryAll<T = Record<string, unknown>>(sql: string, params?: unknown[]): T[] {
  const database = getDatabase()
  const stmt = database.prepare(sql)
  if (params) {
    if (!stmt.bind(params)) { stmt.free(); return [] }
  }
  const results: T[] = []
  while (stmt.step()) results.push(stmt.getAsObject() as T)
  stmt.free()
  return results
}

export function queryOne<T = Record<string, unknown>>(sql: string, params?: unknown[]): T | null {
  const database = getDatabase()
  const stmt = database.prepare(sql)
  if (params) {
    if (!stmt.bind(params)) { stmt.free(); return null }
  }
  let result: T | null = null
  if (stmt.step()) result = stmt.getAsObject() as T
  stmt.free()
  return result
}

export function execute(sql: string, params?: unknown[]): void {
  const database = getDatabase()
  if (params) {
    const stmt = database.prepare(sql)
    if (!stmt.bind(params)) { stmt.free(); return }
    stmt.step()
    stmt.free()
  } else {
    database.run(sql)
  }
  if (currentDbPath) persistDatabase(currentDbPath)
}

export const PluginRepository = {
  findAll(): PluginRecord[] {
    return queryAll<PluginRecord>('SELECT * FROM plugins ORDER BY installed_at DESC')
  },

  findById(id: string): PluginRecord | null {
    return queryOne<PluginRecord>('SELECT * FROM plugins WHERE id = ?', [id])
  },

  findByName(name: string): PluginRecord | null {
    return queryOne<PluginRecord>('SELECT * FROM plugins WHERE name = ?', [name])
  },

  getEnabledPlugins(): PluginRecord[] {
    return queryAll<PluginRecord>('SELECT * FROM plugins WHERE enabled = 1')
  },

  create(record: Omit<PluginRecord, 'installed_at' | 'updated_at'>): void {
    execute(
      `INSERT INTO plugins (id, name, version, display_name, description, author, icon,
        entry_main, entry_renderer, permissions, config_schema, config_data, enabled, installed_path)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [record.id, record.name, record.version, record.display_name, record.description,
        record.author, record.icon, record.entry_main, record.entry_renderer,
        record.permissions, record.config_schema, record.config_data, record.enabled, record.installed_path]
    )
  },

  delete(id: string): void {
    execute('DELETE FROM plugins WHERE id = ?', [id])
  },

  updateEnabled(id: string, enabled: boolean): void {
    execute("UPDATE plugins SET enabled = ?, updated_at = datetime('now', 'localtime') WHERE id = ?", [enabled ? 1 : 0, id])
  },

  getConfig(id: string): PluginConfig {
    const record = this.findById(id)
    if (!record) return {}
    try { return JSON.parse(record.config_data) } catch { return {} }
  },

  updateConfig(id: string, config: PluginConfig): void {
    execute("UPDATE plugins SET config_data = ?, updated_at = datetime('now', 'localtime') WHERE id = ?", [JSON.stringify(config), id])
  },

  update(id: string, updates: Partial<PluginRecord>): void {
    const keys = Object.keys(updates).filter(k => k !== 'id' && k !== 'installed_at')
    if (keys.length === 0) return
    const setClause = keys.map(k => `${k} = ?`).join(', ')
    const values = keys.map(k => (updates as Record<string, unknown>)[k])
    values.push(id)
    execute(`UPDATE plugins SET ${setClause}, updated_at = datetime('now', 'localtime') WHERE id = ?`, values)
  }
}

export const SettingsRepository = {
  get(key: string): string | null {
    const row = queryOne<{ value: string }>('SELECT value FROM settings WHERE key = ?', [key])
    return row?.value ?? null
  },

  set(key: string, value: string): void {
    const existing = queryOne('SELECT 1 as found FROM settings WHERE key = ?', [key])
    if (existing) {
      execute('UPDATE settings SET value = ? WHERE key = ?', [value, key])
    } else {
      execute('INSERT INTO settings (key, value) VALUES (?, ?)', [key, value])
    }
  },

  getAll(): Record<string, string> {
    const rows = queryAll<{ key: string; value: string }>('SELECT key, value FROM settings')
    const result: Record<string, string> = {}
    for (const row of rows) result[row.key] = row.value
    return result
  }
}
