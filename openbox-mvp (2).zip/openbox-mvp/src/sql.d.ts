declare module 'sql.js' {
  interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database
  }

  interface Database {
    run(sql: string, params?: unknown[]): Database
    exec(sql: string): { columns: string[]; values: unknown[][] }[]
    prepare(sql: string): Statement
    export(): Uint8Array
    close(): void
  }

  interface Statement {
    bind(params?: unknown[]): boolean
    step(): boolean
    getAsObject(params?: unknown[]): Record<string, unknown>
    free(): boolean
  }

  export type { SqlJsStatic, Database, Statement }

  export default function initSqlJs(config?: { wasmBinary?: Buffer }): Promise<SqlJsStatic>
}
