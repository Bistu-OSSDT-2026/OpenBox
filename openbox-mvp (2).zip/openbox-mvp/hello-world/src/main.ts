import type { PluginContext } from 'openbox-plugin-api'

export default {
  activate(ctx: PluginContext) {
    ctx.logger.info('Plugin activated')
    ctx.api.notify('Plugin Started', `${ctx.config.displayName || 'My Plugin'} is ready`)

    ctx.api.onEvent('app:ready', () => {
      ctx.logger.info('Application is ready')
    })
  },

  deactivate() {
    console.log('Plugin deactivated')
  },

  onMessage(message: unknown) {
    console.log('Received message:', message)
    return { echo: message }
  }
}
