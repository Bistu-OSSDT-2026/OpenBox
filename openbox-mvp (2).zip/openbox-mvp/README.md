# OpenBox MVP

A minimal, extensible desktop toolbox runtime. OpenBox lets you install and run **plugins** — lightweight Node.js modules that can interact with the system, send notifications, manage files, and more.

This is the **Minimum Viable Product** — no GUI, no web interface, just a **system tray app** + **CLI**.

## Architecture

```
┌─────────────────────────────────────────────────┐
│                   openbox CLI                    │
│  install │ uninstall │ list │ enable/disable     │
│  create-plugin │ info │ tray                     │
└──────────────────────┬──────────────────────────┘
                       │ reads/writes
┌──────────────────────▼──────────────────────────┐
│              SQLite Database (sql.js)             │
│  plugins metadata │ settings │ logs               │
└──────────────────────┬──────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────┐
│            System Tray App (Electron)             │
│  PluginManager → PluginSandbox → Plugin runtime   │
│  PermissionGuard │ EventBus │ PluginProtocol       │
└─────────────────────────────────────────────────┘
```

### Components

| Component | Description |
|-----------|-------------|
| **PluginManager** | Installs, activates, deactivates, and manages plugin lifecycle |
| **PluginSandbox** | Loads and runs each plugin in an isolated environment |
| **PermissionGuard** | Verifies plugins have declared the permissions they request |
| **EventBus** | Pub/sub event system for plugin-to-plugin and host-to-plugin communication |
| **PluginProtocol** | Custom `plugin://` protocol for serving plugin assets |
| **Database** | SQLite (via sql.js) — stores plugin metadata, settings, and logs |

## Quick Start

### Prerequisites

- Node.js 18+
- npm

### Install

```bash
# Clone or download the project
cd openbox-mvp
npm install
npm run build
```

### Use the CLI

```bash
# List installed plugins
openbox list

# Install a plugin from a local directory or .zip file
openbox install ./path/to/my-plugin
openbox install ./plugin-package.zip

# Enable/disable a plugin
openbox enable <plugin-id>
openbox disable <plugin-id>

# View plugin details
openbox info <plugin-id>

# Uninstall a plugin
openbox uninstall <plugin-id>
```

### Start the Tray App

```bash
openbox tray
```

The tray app runs in your system tray. Right-click the icon to:
- See all installed plugins
- Enable/disable plugins
- Install new plugins via file dialog
- View active plugin count

## Creating a Plugin

### Scaffold a new plugin

```bash
openbox create-plugin my-tool
cd my-tool
npm install
```

### Plugin Structure

```
my-tool/
├── plugin.json          # Plugin manifest
├── package.json
├── tsconfig.json
├── src/
│   └── main.ts          # Main process entry
└── dist/                 # Compiled output
```

### plugin.json

```json
{
  "name": "my-tool",
  "version": "0.1.0",
  "displayName": "My Tool",
  "description": "Does something useful",
  "author": "You",
  "main": "dist/main.js",
  "permissions": ["notification", "database:read"],
  "config": {
    "apiKey": {
      "type": "string",
      "label": "API Key",
      "required": true
    }
  }
}
```

### Plugin Entry Point

```typescript
export default {
  activate(ctx) {
    // Called when the plugin is enabled
    ctx.logger.info('Plugin activated')

    // Send a system notification
    ctx.api.notify('Hello', 'Plugin is running')

    // Listen for events
    ctx.api.onEvent('app:ready', () => {
      ctx.logger.info('App is ready')
    })

    // Read/write to shared database
    const rows = ctx.database.query('SELECT * FROM settings')
    ctx.database.execute('INSERT INTO logs (msg) VALUES (?)', ['started'])
  },

  deactivate() {
    // Called when the plugin is disabled
  },

  onMessage(message) {
    // Handle messages from other plugins or the host
    return { echo: message }
  }
}
```

### Build

```bash
npm run build
```

Then install the plugin's `dist/` directory into OpenBox:

```bash
openbox install ./my-tool/dist
```

### Plugin API Reference

#### `ctx.logger`
| Method | Description |
|--------|-------------|
| `info(msg, ...args)` | Log info message |
| `warn(msg, ...args)` | Log warning message |
| `error(msg, ...args)` | Log error message |
| `debug(msg, ...args)` | Log debug message |

#### `ctx.database`
| Method | Description |
|--------|-------------|
| `query(sql, params?)` | Execute SELECT query |
| `execute(sql, params?)` | Execute INSERT/UPDATE/DELETE |

#### `ctx.api`
| Method | Description |
|--------|-------------|
| `notify(title, body?)` | Show system notification |
| `fetch(url, opts?)` | Make HTTP requests |
| `readFile(path)` | Read a file from disk |
| `writeFile(path, data)` | Write a file to disk |
| `emitEvent(event, data?)` | Emit a custom event |
| `onEvent(event, handler)` | Listen for events |

## Permissions

Plugins must declare all permissions they need in `plugin.json`:

| Permission | Description |
|------------|-------------|
| `database:read` | Read from the shared database |
| `database:write` | Write to the shared database |
| `shell:exec` | Execute system commands |
| `network:fetch` | Make network requests |
| `notification` | Send system notifications |
| `clipboard` | Read/write clipboard |
| `dialog` | Open system file dialogs |
| `shortcut` | Register global keyboard shortcuts |

## CLI Reference

```bash
openbox install <path>          Install plugin from .zip or directory
openbox uninstall <id>          Uninstall a plugin
openbox list                    List installed plugins
openbox enable <id>             Enable a plugin
openbox disable <id>            Disable a plugin
openbox info [id]               Show version or plugin details
openbox create-plugin <name>    Scaffold a new plugin project
openbox tray                    Start the system tray app
openbox help                    Show help
```

### Environment Variables

- `OPENBOX_DATA_DIR` — Override the data directory (default: `~/.openbox`)

## Example: Hello World Plugin

```bash
openbox create-plugin hello-world
cd hello-world
npm install
```

Edit `src/main.ts`:

```typescript
export default {
  activate(ctx) {
    ctx.api.notify('Hello World', 'My first plugin is running!')
    ctx.logger.info('Hello World plugin activated')
  },
  deactivate() {
    console.log('Goodbye!')
  }
}
```

Build and install:

```bash
npm run build
openbox install ./dist
```

Then start or restart the tray app and enable the plugin. You'll see a notification.

## License

MIT
